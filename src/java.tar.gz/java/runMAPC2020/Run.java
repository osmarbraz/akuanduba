package runMAPC2020;

public class Run {
    public static void main (String[] args) {
        Control c = new Control();
        GuiText g = new GuiText(c);     
    }
}
